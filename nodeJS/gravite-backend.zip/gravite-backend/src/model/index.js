module.exports.UserModel = require("./user.model");
module.exports.ElectionModel = require("./election.model");
module.exports.PartyModel = require("./party.model");
module.exports.PartyListModel = require("./partylist.model");
module.exports.VoteModel = require("./vote.model");
module.exports.AdminModel = require("./admin.model");