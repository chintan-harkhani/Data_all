module.exports.UserController = require("./user.controller");
module.exports.LoginController = require("./login.controller");
module.exports.ElectionController = require("./election.controller");
module.exports.PartyController = require("./party.controller");
module.exports.PartyListController = require("./partylist.controller");
module.exports.VoteController = require("./vote.controller");
module.exports.CountController = require("./count.controller");
module.exports.AdminController = require("./admin.controller");