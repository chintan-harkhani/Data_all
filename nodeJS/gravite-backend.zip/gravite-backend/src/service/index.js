module.exports.UserService = require("./user.service");
module.exports.ElectionService = require("./election.service");
module.exports.PartyService = require("./party.service");
module.exports.PartyListService = require("./partylist.service");
module.exports.VoteService = require("./vote.service");
module.exports.CountService = require("./count.service");
module.exports.AdminService = require("./admin.service");